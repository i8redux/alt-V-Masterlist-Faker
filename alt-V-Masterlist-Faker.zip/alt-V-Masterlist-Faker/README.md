# alt:V Masterlist Faker

## Usage
Get your Masterlist Token and edit the [config.json]
Build the files and start your server.

### Example alt:V Resource Config
```
type: "csharp",
main: "altV_FakeMasterlist.dll"
```

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
